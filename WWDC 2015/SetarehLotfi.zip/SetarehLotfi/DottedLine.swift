//
//  DottedLine.swift
//  Setareh Lotfi
//
//  Created by Setareh Lotfi on 4/22/15.
//  Copyright (c) 2015 Setareh Lotfi. All rights reserved.
//

import Foundation

//class DottedLine{
//    init(){
//        
//        super.init();
//    }
//    func drawRect(rect: CGRect){
//        
//    }
//    
//    
//    
//}