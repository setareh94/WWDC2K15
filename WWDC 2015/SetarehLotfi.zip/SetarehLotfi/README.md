<h1>About Me</h1>
<p>This is iOS app I made as interacting version of my solid and boring resume which gives the recruiter the access to both my iOS skills and my amazing life as a CS students.</p>
<p1> I have released the app on the AppStore but it is still "Under The Review" I will update this section with the link to AppStore as soon as it passed Apple requirments</p1>

<p>Here are the screenshots of the app:<p>
	
<img src="https://github.com/setareh94/AboutMe/blob/master/ScreenShots/iOS%20Simulator%20Screen%20Shot%20Aug%2021%2C%202014%2C%2011.50.24%20PM.png" alt="homepage" height"560" width="240" style="float:left">
<img src="https://github.com/setareh94/AboutMe/blob/master/ScreenShots/iOS%20Simulator%20Screen%20Shot%20Aug%2021%2C%202014%2C%2011.51.49%20PM.png" alt="info" height"560" width="240" style="float:right">
<img src="https://github.com/setareh94/AboutMe/blob/master/ScreenShots/iOS%20Simulator%20Screen%20Shot%20Aug%2021%2C%202014%2C%2011.51.39%20PM.png" alt="app view" height"560" width="240">
