//
//  AppDelegate.h
//  Setareh Lotfi
//
//  Created by Setareh Lotfi on 4/10/15.
//  Copyright (c) 2014 setarehlotfi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

