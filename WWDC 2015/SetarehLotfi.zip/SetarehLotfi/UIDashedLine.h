//
//  UIView+UIDashedLine.h
//  Setareh Lotfi
//
//  Created by Setareh Lotfi on 4/22/15.
//  Copyright (c) 2015 Setareh Lotfi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDashedLine : UIView

@end
